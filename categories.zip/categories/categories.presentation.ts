import { useParams } from 'next/navigation';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { FormInstance } from 'antd';
import { formErrorHandler } from 'papak/utils/formErrorHandler';
import { CustomError } from 'papak/utils/request/interceptors';
import { useSearchParamsToObject } from 'papak/utils/useSearchParamsToObject';
import { CategoriesService } from './categories.service';
import { categoriesStore } from './categories.store';
import {
  Categories,
  CategoriesCreateParams,
} from './domains/models/Categories';

const categoriesQueryKeys = {
  LIST: 'categories_List',
  RETRIEVE: 'categories_Retrieve',
};

export function CategoriesPresentation() {
  const Service = CategoriesService();
  const queryClient = useQueryClient();

  return {
    useCategoriesList: () => {
      const variables = useSearchParamsToObject();

      return useQuery({
        queryKey: [categoriesQueryKeys.LIST, JSON.stringify(variables)],
        queryFn: () => Service.list(variables),
        enabled: Object.keys(variables || {}).length > 0,
      });
    },

    useCategoriesCreate: (form: FormInstance) => {
      return useMutation({
        mutationFn: (params: CategoriesCreateParams) => Service.create(params),
        onSuccess() {
          queryClient.invalidateQueries({
            queryKey: [categoriesQueryKeys.LIST],
          });

          categoriesStore.setState({
            addModalOpen: false,
          });
        },
        onError(error) {
          const errorDetails = error as unknown as CustomError;

          if (form) {
            formErrorHandler(form, errorDetails?.details);
          }
        },
      });
    },

    useCategoriesRetrieve: () => {
      const { id } = useParams();

      return useQuery({
        queryKey: [categoriesQueryKeys.RETRIEVE, id],
        queryFn: () => Service.retrieve(id as string),
        enabled: !!id,
      });
    },

    useCategoriesUpdate: (form: FormInstance) => {
      const selectedRowState = categoriesStore.getState('selectedRowState');
      const id = selectedRowState[0]?.id;

      return useMutation({
        mutationFn: (params: Categories) =>
          Service.update(id, {
            category_title: params?.category_title,
          }),
        onSuccess() {
          queryClient.invalidateQueries({
            queryKey: [categoriesQueryKeys.LIST],
          });
          queryClient.invalidateQueries({
            queryKey: [categoriesQueryKeys.RETRIEVE],
          });

          categoriesStore.setState({
            editModalOpen: false,
          });
        },

        onError(error) {
          const errorDetails = error as unknown as CustomError;

          if (form) {
            formErrorHandler(form, errorDetails?.details);
          }
        },
      });
    },

    useCategoriesDestroy: () => {
      return useMutation({
        mutationFn: (variables: { id: number }) =>
          Service.destroy(variables.id),
        onSuccess() {
          queryClient.invalidateQueries({
            queryKey: [categoriesQueryKeys.LIST],
          });
          queryClient.invalidateQueries({
            queryKey: [categoriesQueryKeys.RETRIEVE],
          });

          categoriesStore.setState({
            deleteModalOpen: false,
          });
        },
      });
    },
  };
}
