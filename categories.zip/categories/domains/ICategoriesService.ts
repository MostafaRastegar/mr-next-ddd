import {
  PaginationList,
  PaginationParams,
  ResponseObject,
} from 'papak/_modulesTypes';
import { Categories, CategoriesCreateParams } from './models/Categories';

export interface ICategoriesService {
  list(
    params: PaginationParams,
  ): Promise<ResponseObject<PaginationList<Categories>>>;
  create(body: CategoriesCreateParams): Promise<ResponseObject<Categories>>;
  retrieve(id: string): Promise<ResponseObject<Categories>>;
  update(
    id: number,
    body: CategoriesCreateParams,
  ): Promise<ResponseObject<Categories>>;
  destroy(id: number): Promise<ResponseObject<null>>;
}
