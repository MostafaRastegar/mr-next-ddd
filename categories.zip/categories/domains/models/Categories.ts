export interface Categories {
  id: number;
  category_title: string;
}

// Common request/response DTOs for categories
export interface CategoriesCreateParams extends Omit<Categories, 'id'> {}
export interface CategoriesResponse {
  data: Categories;
  message?: string;
  code?: number;
}
