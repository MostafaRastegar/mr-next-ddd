import createStore from 'react-constore';
import { Categories } from './domains/models/Categories';

interface CategoriesStore {
  selectedRowState: Categories[];
  editModalOpen: boolean;
  addModalOpen: boolean;
  deleteModalOpen: boolean;
}

export const categoriesStore = createStore<CategoriesStore>({
  selectedRowState: [],
  editModalOpen: false,
  addModalOpen: false,
  deleteModalOpen: false,
});
