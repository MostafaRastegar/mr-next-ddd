import { serviceHandler } from 'papak/helpers/serviceHandler';
import request from 'papak/utils/request';
import { endpoints } from '@/constants/endpoints';
import { ICategoriesService } from './domains/ICategoriesService';

export function CategoriesService(): ICategoriesService {
  return {
    list: params =>
      serviceHandler(() =>
        request().get(endpoints.CATEGORIES.GET_API_V1_CATEGORIES(), {
          params,
        }),
      ),
    create: body =>
      serviceHandler(() =>
        request().post(endpoints.CATEGORIES.POST_API_V1_CATEGORIES(), body),
      ),
    retrieve: id =>
      serviceHandler(() =>
        request().get(endpoints.CATEGORIES.GET_API_V1_CATEGORIES_ID(id)),
      ),
    update: (id, body) =>
      serviceHandler(() =>
        request().put(endpoints.CATEGORIES.PUT_API_V1_CATEGORIES_ID(id), body),
      ),
    destroy: id =>
      serviceHandler(() =>
        request().delete(endpoints.CATEGORIES.DELETE_API_V1_CATEGORIES_ID(id)),
      ),
  };
}
